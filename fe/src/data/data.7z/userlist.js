
const test =[ 
  {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",}, {
    name: "홍길동",
    currentGroup: "A",
  mail:"홍길동@naver.com",},
    ]
    export default test; 

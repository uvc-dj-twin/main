
const test =
{
serialData:{
  title:'일자 별 추이',
  labels:["2024-01-01","2024-01-02","2024-01-03","2024-01-04","2024-01-05",],
  data:[30,40,50,60,30],
},

totalCount:{title:'총수',labels: ['정상','이상'], data: [100, 30]},
faultType:{title:'불량유형', labels: ['베어링 불량', '잠금 풀림', '회전이상'] , data: [10,8,12]}
}
export default test; 
